import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { data: students, error } = await supabase.from('students').select('*');
    if (error) throw error;

    const total = students ? students.length : 0;
    const highRisk = students ? students.filter(s => s.risk_level === 'High Risk').length : 0;
    const moderateRisk = students ? students.filter(s => s.risk_level === 'Moderate Risk').length : 0;
    const lowRisk = students ? students.filter(s => s.risk_level === 'Low Risk').length : 0;
    const topPerformer = students ? students.filter(s => s.risk_level === 'Top Performer').length : 0;

    const avgGPA = total > 0 ? (students.reduce((acc, s) => acc + (s.predicted_gpa || 3.0), 0) / total).toFixed(2) : '3.15';

    res.status(200).json({
      total_students: total,
      high_risk_count: highRisk,
      moderate_risk_count: moderateRisk,
      low_risk_count: lowRisk,
      top_performer_count: topPerformer,
      avg_predicted_gpa: avgGPA,
      feature_importance: [
        { feature: 'Midterm Exam Grade', weight: 0.35 },
        { feature: 'Assignment Completion', weight: 0.25 },
        { feature: 'Attendance Rate', weight: 0.20 },
        { feature: 'Weekly Study Hours', weight: 0.10 },
        { feature: 'LMS Activity Score', weight: 0.10 },
      ]
    });
  } catch (err) {
    console.error('API Error /api/analytics:', err);
    res.status(500).json({ error: err.message });
  }
}
