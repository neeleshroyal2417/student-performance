import supabase from './db-client.js';

function computePrediction(midterm, attendance, studyHours, assignment, lms) {
  const m = Math.max(0, Math.min(100, Number(midterm) || 0));
  const a = Math.max(0, Math.min(100, Number(attendance) || 0));
  const s = Math.max(0, Math.min(40, Number(studyHours) || 0));
  const ass = Math.max(0, Math.min(100, Number(assignment) || 0));
  const l = Math.max(0, Math.min(100, Number(lms) || 0));

  const studyNorm = Math.min(100, (s / 25) * 100);
  const score = (m * 0.35) + (ass * 0.25) + (a * 0.20) + (studyNorm * 0.10) + (l * 0.10);
  const predicted_score = Math.round(score * 10) / 10;

  let gpa = 0.0;
  if (predicted_score >= 93) gpa = 4.0;
  else if (predicted_score >= 90) gpa = 3.7;
  else if (predicted_score >= 87) gpa = 3.3;
  else if (predicted_score >= 83) gpa = 3.0;
  else if (predicted_score >= 80) gpa = 2.7;
  else if (predicted_score >= 77) gpa = 2.3;
  else if (predicted_score >= 73) gpa = 2.0;
  else if (predicted_score >= 70) gpa = 1.7;
  else if (predicted_score >= 65) gpa = 1.3;
  else if (predicted_score >= 60) gpa = 1.0;
  else gpa = 0.0;

  const predicted_gpa = Math.round(gpa * 100) / 100;

  let risk_level = 'Low Risk';
  if (predicted_gpa < 2.3 || a < 72 || m < 60) {
    risk_level = 'High Risk';
  } else if (predicted_gpa < 2.9 || a < 82 || ass < 80) {
    risk_level = 'Moderate Risk';
  } else if (predicted_gpa >= 3.6 && a >= 90 && ass >= 90) {
    risk_level = 'Top Performer';
  }

  return { predicted_gpa, risk_level };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body;
      const { predicted_gpa, risk_level } = computePrediction(
        body.midterm_score,
        body.attendance_rate,
        body.weekly_study_hours,
        body.assignment_completion_rate,
        body.lms_engagement_score
      );

      const newStudent = {
        student_id: body.student_id || `STU-${Math.floor(1000 + Math.random() * 9000)}`,
        name: body.name,
        email: body.email,
        major: body.major || 'Computer Science',
        year_level: body.year_level || 'Sophomore',
        overall_gpa: body.overall_gpa || 3.1,
        predicted_gpa,
        risk_level,
        attendance_rate: body.attendance_rate || 80,
        weekly_study_hours: body.weekly_study_hours || 10,
        assignment_completion_rate: body.assignment_completion_rate || 85,
        midterm_score: body.midterm_score || 75,
        lms_engagement_score: body.lms_engagement_score || 70
      };

      const { data, error } = await supabase
        .from('students')
        .insert(newStudent)
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const body = req.body;
      const { predicted_gpa, risk_level } = computePrediction(
        body.midterm_score,
        body.attendance_rate,
        body.weekly_study_hours,
        body.assignment_completion_rate,
        body.lms_engagement_score
      );

      const { data, error } = await supabase
        .from('students')
        .update({
          name: body.name,
          email: body.email,
          major: body.major,
          year_level: body.year_level,
          overall_gpa: body.overall_gpa,
          predicted_gpa,
          risk_level,
          attendance_rate: body.attendance_rate,
          weekly_study_hours: body.weekly_study_hours,
          assignment_completion_rate: body.assignment_completion_rate,
          midterm_score: body.midterm_score,
          lms_engagement_score: body.lms_engagement_score
        })
        .eq('id', body.id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API Error /api/students:', err);
    res.status(500).json({ error: err.message });
  }
}
