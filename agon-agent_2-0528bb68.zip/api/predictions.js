import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { student_id } = req.query;
      let query = supabase.from('prediction_logs').select('*').order('timestamp', { ascending: false });
      if (student_id) query = query.eq('student_id', student_id);
      
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const { student_id, input_factors, predicted_gpa, risk_level, key_factors, ai_recommendation } = req.body;

      const { data, error } = await supabase
        .from('prediction_logs')
        .insert({
          student_id,
          input_factors,
          predicted_gpa,
          risk_level,
          key_factors,
          ai_recommendation,
          timestamp: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API Error /api/predictions:', err);
    res.status(500).json({ error: err.message });
  }
}
