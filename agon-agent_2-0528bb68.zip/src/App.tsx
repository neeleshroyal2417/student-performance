import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import StudentsList from './pages/StudentsList';
import WhatIfSimulator from './pages/WhatIfSimulator';
import AnalyticsPage from './pages/AnalyticsPage';
import StudentPortal from './pages/StudentPortal';
import InterventionsPage from './pages/InterventionsPage';
import { handleGoogleRedirect } from './lib/googleAuth';

// Initialize OAuth redirect listener
handleGoogleRedirect();

function MainLayout() {
  const { user, role } = useAuth();

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 bg-slate-950 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/students" element={<StudentsList />} />
            <Route path="/simulator" element={<WhatIfSimulator />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/student-portal" element={<StudentPortal />} />
            <Route path="/interventions" element={<InterventionsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/*"
            element={
              <ProtectedRoute>
                <MainLayout />
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
