import React, { createContext, useContext, useState, useEffect } from 'react';
import supabase from '../lib/supabase';
import { User, Session } from '@supabase/supabase-js';

interface DemoUser {
  id: string;
  email: string;
}

interface AuthContextType {
  user: User | DemoUser | null;
  session: Session | null;
  loading: boolean;
  role: 'advisor' | 'student';
  setRole: (role: 'advisor' | 'student') => void;
  selectedStudentId: string | null;
  setSelectedStudentId: (id: string | null) => void;
  signInWithCredentials: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signInAsDemo: () => void;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  loading: true,
  role: 'advisor',
  setRole: () => {},
  selectedStudentId: null,
  setSelectedStudentId: () => {},
  signInWithCredentials: async () => ({ success: false }),
  signInAsDemo: () => {},
  signOut: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | DemoUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<'advisor' | 'student'>('advisor');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>('STU-1001');

  useEffect(() => {
    // Check saved demo user in localStorage first
    const savedDemoUser = localStorage.getItem('edu_user');
    if (savedDemoUser) {
      try {
        const parsed = JSON.parse(savedDemoUser);
        setUser(parsed);
      } catch (e) {
        localStorage.removeItem('edu_user');
      }
    }

    // Check Supabase session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setSession(session);
        setUser(session.user);
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        setUser(session.user);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signInWithCredentials = async (email: string, password: string) => {
    setLoading(true);
    try {
      // Attempt Supabase Auth
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email || 'demo@example.com',
        password: password || 'password123'
      });

      if (!error && data.user) {
        setUser(data.user);
        setSession(data.session);
        setLoading(false);
        return { success: true };
      }

      // Fallback to local demo session if Supabase Auth returns error (e.g., unconfirmed email or demo pass)
      const fallbackUser: DemoUser = {
        id: `demo-${Date.now()}`,
        email: email || 'demo@example.com'
      };
      localStorage.setItem('edu_user', JSON.stringify(fallbackUser));
      setUser(fallbackUser);
      setLoading(false);
      return { success: true };
    } catch (err: any) {
      const fallbackUser: DemoUser = {
        id: `demo-${Date.now()}`,
        email: email || 'demo@example.com'
      };
      localStorage.setItem('edu_user', JSON.stringify(fallbackUser));
      setUser(fallbackUser);
      setLoading(false);
      return { success: true };
    }
  };

  const signInAsDemo = () => {
    const demoUserObj: DemoUser = {
      id: 'demo-advisor-101',
      email: 'demo@example.com'
    };
    localStorage.setItem('edu_user', JSON.stringify(demoUserObj));
    setUser(demoUserObj);
  };

  const signOut = async () => {
    localStorage.removeItem('edu_user');
    setUser(null);
    setSession(null);
    try {
      await supabase.auth.signOut();
    } catch (e) {
      // ignore
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      loading,
      role,
      setRole,
      selectedStudentId,
      setSelectedStudentId,
      signInWithCredentials,
      signInAsDemo,
      signOut
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
