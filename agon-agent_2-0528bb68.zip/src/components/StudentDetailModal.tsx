import React, { useState } from 'react';
import {
  X,
  User,
  GraduationCap,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  BookOpen,
  Award,
  Sparkles,
  ShieldAlert,
  Plus
} from 'lucide-react';
import { calculateStudentPrediction } from '../lib/predictionEngine';

interface Student {
  id: number;
  student_id: string;
  name: string;
  email: string;
  major: string;
  year_level: string;
  overall_gpa: number;
  predicted_gpa: number;
  risk_level: string;
  attendance_rate: number;
  weekly_study_hours: number;
  assignment_completion_rate: number;
  midterm_score: number;
  lms_engagement_score: number;
}

interface StudentDetailModalProps {
  student: Student | null;
  onClose: () => void;
  onOpenIntervention: (studentId: string) => void;
  onUpdateStudent?: (updated: Student) => void;
}

export default function StudentDetailModal({
  student,
  onClose,
  onOpenIntervention,
  onUpdateStudent
}: StudentDetailModalProps) {
  if (!student) return null;

  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({ ...student });

  const prediction = calculateStudentPrediction({
    midterm_score: formData.midterm_score,
    attendance_rate: formData.attendance_rate,
    weekly_study_hours: formData.weekly_study_hours,
    assignment_completion_rate: formData.assignment_completion_rate,
    lms_engagement_score: formData.lms_engagement_score
  });

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'High Risk':
        return <span className="px-2.5 py-1 text-xs font-medium bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full flex items-center space-x-1"><AlertTriangle className="w-3 h-3" /><span>High Risk</span></span>;
      case 'Moderate Risk':
        return <span className="px-2.5 py-1 text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full flex items-center space-x-1"><Clock className="w-3 h-3" /><span>Moderate Risk</span></span>;
      case 'Top Performer':
        return <span className="px-2.5 py-1 text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center space-x-1"><Award className="w-3 h-3" /><span>Top Performer</span></span>;
      default:
        return <span className="px-2.5 py-1 text-xs font-medium bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full flex items-center space-x-1"><CheckCircle className="w-3 h-3" /><span>Low Risk</span></span>;
    }
  };

  const handleSaveMetrics = async () => {
    try {
      const updatedObj = {
        ...formData,
        predicted_gpa: prediction.predicted_gpa,
        risk_level: prediction.risk_level
      };

      const res = await fetch('/api/students', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedObj)
      });

      if (res.ok) {
        const data = await res.json();
        if (onUpdateStudent) onUpdateStudent(data);
        setEditing(false);
      }
    } catch (err) {
      console.error('Failed to update student metrics:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-indigo-500/20">
              {student.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h2 className="text-xl font-bold text-white">{student.name}</h2>
                {getRiskBadge(prediction.risk_level)}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                ID: <span className="text-slate-200 font-medium">{student.student_id}</span> • {student.major} ({student.year_level})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-800">
          <button
            onClick={() => onOpenIntervention(student.student_id)}
            className="flex items-center space-x-1.5 bg-rose-600 hover:bg-rose-500 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-md shadow-rose-900/20"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Log Academic Intervention</span>
          </button>

          <button
            onClick={() => setEditing(!editing)}
            className="text-xs font-medium text-indigo-400 hover:text-indigo-300 underline"
          >
            {editing ? 'Cancel Editing' : 'Edit Performance Metrics'}
          </button>
        </div>

        {/* Main Predictions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 text-center space-y-1">
            <p className="text-xs text-slate-400 font-medium">Current Overall GPA</p>
            <p className="text-2xl font-bold text-white">{student.overall_gpa?.toFixed(2) ?? '3.10'}</p>
            <p className="text-[10px] text-slate-500">Historical Registrar Record</p>
          </div>

          <div className="bg-gradient-to-br from-indigo-900/40 to-violet-900/40 p-4 rounded-xl border border-indigo-500/30 text-center space-y-1">
            <p className="text-xs text-indigo-300 font-semibold flex items-center justify-center space-x-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Predicted GPA</span>
            </p>
            <p className="text-3xl font-extrabold text-indigo-200">{prediction.predicted_gpa.toFixed(2)}</p>
            <p className="text-[10px] text-indigo-400">Score Projection: {prediction.predicted_score}%</p>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 text-center space-y-1">
            <p className="text-xs text-slate-400 font-medium">Risk Score</p>
            <p className={`text-2xl font-bold ${prediction.risk_score > 35 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {prediction.risk_score}/100
            </p>
            <p className="text-[10px] text-slate-500">(Higher score = greater drop risk)</p>
          </div>
        </div>

        {/* Performance Inputs Section */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-200 flex items-center space-x-2">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>Academic Inputs & Study Profile</span>
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
              <p className="text-[11px] text-slate-400">Midterm Score</p>
              {editing ? (
                <input
                  type="number"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-white"
                  value={formData.midterm_score}
                  onChange={e => setFormData({ ...formData, midterm_score: parseFloat(e.target.value) || 0 })}
                />
              ) : (
                <p className="text-base font-bold text-slate-100">{formData.midterm_score}%</p>
              )}
            </div>

            <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
              <p className="text-[11px] text-slate-400">Attendance Rate</p>
              {editing ? (
                <input
                  type="number"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-white"
                  value={formData.attendance_rate}
                  onChange={e => setFormData({ ...formData, attendance_rate: parseFloat(e.target.value) || 0 })}
                />
              ) : (
                <p className="text-base font-bold text-slate-100">{formData.attendance_rate}%</p>
              )}
            </div>

            <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
              <p className="text-[11px] text-slate-400">Weekly Study</p>
              {editing ? (
                <input
                  type="number"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-white"
                  value={formData.weekly_study_hours}
                  onChange={e => setFormData({ ...formData, weekly_study_hours: parseFloat(e.target.value) || 0 })}
                />
              ) : (
                <p className="text-base font-bold text-slate-100">{formData.weekly_study_hours} hrs/wk</p>
              )}
            </div>

            <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
              <p className="text-[11px] text-slate-400">Assignments</p>
              {editing ? (
                <input
                  type="number"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-white"
                  value={formData.assignment_completion_rate}
                  onChange={e => setFormData({ ...formData, assignment_completion_rate: parseFloat(e.target.value) || 0 })}
                />
              ) : (
                <p className="text-base font-bold text-slate-100">{formData.assignment_completion_rate}%</p>
              )}
            </div>

            <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
              <p className="text-[11px] text-slate-400">LMS Activity</p>
              {editing ? (
                <input
                  type="number"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-white"
                  value={formData.lms_engagement_score}
                  onChange={e => setFormData({ ...formData, lms_engagement_score: parseFloat(e.target.value) || 0 })}
                />
              ) : (
                <p className="text-base font-bold text-slate-100">{formData.lms_engagement_score} pts</p>
              )}
            </div>
          </div>

          {editing && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveMetrics}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-1.5 rounded-lg text-xs font-medium transition-all"
              >
                Save Recalculated Prediction
              </button>
            </div>
          )}
        </div>

        {/* AI Key Factors & Study Guidance */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-800 space-y-2">
            <h4 className="text-xs font-semibold text-rose-400 uppercase tracking-wider flex items-center space-x-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Primary Performance Drivers</span>
            </h4>
            <ul className="space-y-1.5">
              {prediction.key_factors.map((factor, i) => (
                <li key={i} className="text-xs text-slate-300 flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                  <span>{factor}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-indigo-950/30 p-4 rounded-xl border border-indigo-900/40 space-y-2">
            <h4 className="text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Recommended Intervention Plan</span>
            </h4>
            <ul className="space-y-1.5">
              {prediction.recommendations.map((rec, i) => (
                <li key={i} className="text-xs text-indigo-200 flex items-start space-x-2">
                  <span className="text-indigo-400 font-bold">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

      </div>
    </div>
  );
}
