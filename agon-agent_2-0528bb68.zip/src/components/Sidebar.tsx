import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  LayoutDashboard,
  Users,
  Sliders,
  BarChart3,
  ShieldAlert,
  GraduationCap,
  BookOpen
} from 'lucide-react';

export default function Sidebar() {
  const { role } = useAuth();

  const advisorNavs = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/students', label: 'Student Directory', icon: Users },
    { to: '/simulator', label: 'What-If Simulator', icon: Sliders },
    { to: '/analytics', label: 'Model & Insights', icon: BarChart3 },
    { to: '/interventions', label: 'Academic Support', icon: ShieldAlert },
  ];

  const studentNavs = [
    { to: '/student-portal', label: 'My Performance', icon: GraduationCap },
    { to: '/simulator', label: 'Grade Predictor', icon: Sliders },
    { to: '/analytics', label: 'Class Insights', icon: BarChart3 },
  ];

  const navs = role === 'advisor' ? advisorNavs : studentNavs;

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between hidden md:flex min-h-[calc(100vh-57px)] p-4">
      <div className="space-y-6">
        <div>
          <p className="px-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Navigation Menu
          </p>
          <nav className="space-y-1">
            {navs.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  className={({ isActive }) =>
                    `flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/30 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`
                  }
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        {role === 'advisor' && (
          <div className="p-3.5 bg-gradient-to-b from-slate-800/80 to-slate-800/30 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="flex items-center space-x-2 text-indigo-400">
              <BookOpen className="w-4 h-4" />
              <span className="text-xs font-semibold">Active AI Model</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Multi-Variable Weighted Linear Regression & Decision Risk Classification Engine.
            </p>
            <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400">
              <span>Predictive Accuracy</span>
              <span className="font-semibold text-emerald-400">92.4%</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800 text-center text-[11px] text-slate-500">
        EduPredict AI System &copy; 2025
      </div>
    </aside>
  );
}
