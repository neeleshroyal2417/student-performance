import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Brain, UserCheck, GraduationCap, LogOut, Bell, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenAddStudent?: () => void;
}

export default function Navbar({ onOpenAddStudent }: NavbarProps) {
  const { user, role, setRole, signOut } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 lg:px-6 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-tr from-indigo-600 to-violet-500 rounded-xl shadow-lg shadow-indigo-500/20 text-white">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-lg text-white tracking-tight">EduPredict AI</span>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-full">
                v2.4 ML
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">Student Performance Prediction & Academic Risk Intelligence</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* View Role Switcher */}
          <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700">
            <button
              onClick={() => setRole('advisor')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                role === 'advisor'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Advisor Portal</span>
            </button>
            <button
              onClick={() => setRole('student')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                role === 'student'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Student View</span>
            </button>
          </div>

          {role === 'advisor' && onOpenAddStudent && (
            <button
              onClick={onOpenAddStudent}
              className="hidden sm:flex items-center space-x-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all shadow-md shadow-emerald-900/20"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>+ Add Student</span>
            </button>
          )}

          {/* User badge */}
          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-indigo-300">
              {user?.email?.[0].toUpperCase() || 'U'}
            </div>
            <div className="hidden lg:block text-left">
              <p className="text-xs font-medium text-slate-200 truncate max-w-[120px]">{user?.email}</p>
              <p className="text-[10px] text-slate-400 capitalize">{role} Access</p>
            </div>
            <button
              onClick={signOut}
              title="Sign Out"
              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
