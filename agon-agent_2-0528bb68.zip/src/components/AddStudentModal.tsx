import React, { useState } from 'react';
import { X, UserPlus, Sparkles } from 'lucide-react';
import { calculateStudentPrediction } from '../lib/predictionEngine';

interface AddStudentModalProps {
  onClose: () => void;
  onAdded: () => void;
}

export default function AddStudentModal({ onClose, onAdded }: AddStudentModalProps) {
  const [formData, setFormData] = useState({
    student_id: `STU-${Math.floor(1000 + Math.random() * 9000)}`,
    name: '',
    email: '',
    major: 'Computer Science',
    year_level: 'Sophomore',
    overall_gpa: 3.2,
    midterm_score: 78,
    attendance_rate: 85,
    weekly_study_hours: 12,
    assignment_completion_rate: 88,
    lms_engagement_score: 75
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const previewPrediction = calculateStudentPrediction({
    midterm_score: formData.midterm_score,
    attendance_rate: formData.attendance_rate,
    weekly_study_hours: formData.weekly_study_hours,
    assignment_completion_rate: formData.assignment_completion_rate,
    lms_engagement_score: formData.lms_engagement_score
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const payload = {
        ...formData,
        predicted_gpa: previewPrediction.predicted_gpa,
        risk_level: previewPrediction.risk_level
      };

      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error('Failed to create student record');
      }

      onAdded();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error creating student');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl p-6 shadow-2xl text-slate-100 space-y-5">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <UserPlus className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">Enroll & Predict New Student</h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800">
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs rounded-xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Student Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Sarah Jenkins"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-500"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Email Address *</label>
              <input
                type="email"
                required
                placeholder="sarah.j@university.edu"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-500"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Major</label>
              <select
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-500"
                value={formData.major}
                onChange={e => setFormData({ ...formData, major: e.target.value })}
              >
                <option value="Computer Science">Computer Science</option>
                <option value="Data Science">Data Science</option>
                <option value="Electrical Engineering">Electrical Engineering</option>
                <option value="Biology">Biology</option>
                <option value="Economics">Economics</option>
                <option value="Mathematics">Mathematics</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Year Level</label>
              <select
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-500"
                value={formData.year_level}
                onChange={e => setFormData({ ...formData, year_level: e.target.value })}
              >
                <option value="Freshman">Freshman</option>
                <option value="Sophomore">Sophomore</option>
                <option value="Junior">Junior</option>
                <option value="Senior">Senior</option>
              </select>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-3">
            <p className="font-semibold text-slate-300 mb-2">Initial Academic Metrics for Prediction</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Midterm Exam (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.midterm_score}
                  onChange={e => setFormData({ ...formData, midterm_score: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Attendance Rate (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.attendance_rate}
                  onChange={e => setFormData({ ...formData, attendance_rate: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Study Hours (hrs/wk)</label>
                <input
                  type="number"
                  min="0"
                  max="40"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.weekly_study_hours}
                  onChange={e => setFormData({ ...formData, weekly_study_hours: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Assignments (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.assignment_completion_rate}
                  onChange={e => setFormData({ ...formData, assignment_completion_rate: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">LMS Activity Score</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.lms_engagement_score}
                  onChange={e => setFormData({ ...formData, lms_engagement_score: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Prior GPA</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="4.0"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2 text-white"
                  value={formData.overall_gpa}
                  onChange={e => setFormData({ ...formData, overall_gpa: parseFloat(e.target.value) || 0 })}
                />
              </div>
            </div>
          </div>

          {/* Instant AI Prediction Preview */}
          <div className="bg-indigo-950/40 border border-indigo-500/30 p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <div>
                <p className="text-[11px] font-semibold text-indigo-200">Live AI Prediction Preview</p>
                <p className="text-[10px] text-indigo-400">Classified Tier: <span className="font-bold">{previewPrediction.risk_level}</span></p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-indigo-200">{previewPrediction.predicted_gpa.toFixed(2)} GPA</p>
              <p className="text-[10px] text-slate-400">{previewPrediction.predicted_score}% projected score</p>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl transition-all font-semibold shadow-lg shadow-indigo-500/20 flex items-center space-x-1.5"
            >
              {loading ? 'Saving...' : 'Save & Calculate'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
