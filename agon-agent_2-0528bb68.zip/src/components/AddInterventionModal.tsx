import React, { useState } from 'react';
import { X, ShieldAlert, Save } from 'lucide-react';

interface AddInterventionModalProps {
  defaultStudentId?: string;
  onClose: () => void;
  onAdded: () => void;
}

export default function AddInterventionModal({
  defaultStudentId = '',
  onClose,
  onAdded
}: AddInterventionModalProps) {
  const [studentId, setStudentId] = useState(defaultStudentId);
  const [advisorName, setAdvisorName] = useState('Dr. Marcus Vance');
  const [title, setTitle] = useState('');
  const [type, setType] = useState('Tutoring');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/interventions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: studentId,
          advisor_name: advisorName,
          title: title || `${type} Session for Academic Recovery`,
          type,
          status: 'In Progress',
          notes
        })
      });

      if (res.ok) {
        onAdded();
        onClose();
      }
    } catch (err) {
      console.error('Failed to log intervention:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl text-slate-100 space-y-4">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <h2 className="text-base font-bold text-white">Log Academic Intervention</h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Student ID *</label>
            <input
              type="text"
              required
              placeholder="e.g. STU-1001"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white"
              value={studentId}
              onChange={e => setStudentId(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Intervention Type</label>
            <select
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white"
              value={type}
              onChange={e => setType(e.target.value)}
            >
              <option value="Tutoring">1-on-1 Peer Tutoring</option>
              <option value="Academic Counseling">Academic Counseling Session</option>
              <option value="Parent Contact">Parent / Guardian Contact</option>
              <option value="Study Group">Assigned Study Group</option>
              <option value="Wellness Check">Student Wellness Check</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Advisor / Staff Name</label>
            <input
              type="text"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white"
              value={advisorName}
              onChange={e => setAdvisorName(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Action Title</label>
            <input
              type="text"
              placeholder="e.g. Scheduled Weekly Math Tutoring"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Intervention Notes & Goals</label>
            <textarea
              rows={3}
              placeholder="Detail agreed action items, goals, and follow-up dates..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white resize-none"
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-semibold flex items-center space-x-1.5 shadow-md shadow-rose-900/20"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{loading ? 'Saving...' : 'Record Action'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
