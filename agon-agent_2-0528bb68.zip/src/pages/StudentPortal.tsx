import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { GraduationCap, Sparkles, BookOpen, AlertTriangle, CheckCircle2, Sliders } from 'lucide-react';
import { calculateStudentPrediction } from '../lib/predictionEngine';

interface Student {
  id: number;
  student_id: string;
  name: string;
  email: string;
  major: string;
  year_level: string;
  overall_gpa: number;
  predicted_gpa: number;
  risk_level: string;
  attendance_rate: number;
  weekly_study_hours: number;
  assignment_completion_rate: number;
  midterm_score: number;
  lms_engagement_score: number;
}

export default function StudentPortal() {
  const { selectedStudentId, setSelectedStudentId } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/api/students');
        if (res.ok) {
          const data = await res.json();
          setStudents(data);
          const found = data.find((s: Student) => s.student_id === selectedStudentId) || data[0];
          setCurrentStudent(found);
        }
      } catch (err) {
        console.error('Error in student portal:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [selectedStudentId]);

  if (loading || !currentStudent) {
    return (
      <div className="p-8 text-center text-slate-400 text-xs">
        Loading personalized student dashboard...
      </div>
    );
  }

  const prediction = calculateStudentPrediction({
    midterm_score: currentStudent.midterm_score,
    attendance_rate: currentStudent.attendance_rate,
    weekly_study_hours: currentStudent.weekly_study_hours,
    assignment_completion_rate: currentStudent.assignment_completion_rate,
    lms_engagement_score: currentStudent.lms_engagement_score
  });

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-6xl mx-auto text-slate-100">
      
      {/* Student Selector Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-slate-900 border border-slate-800 p-5 rounded-3xl gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center font-bold text-white text-lg shadow-lg">
            {currentStudent.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">{currentStudent.name}</h1>
            <p className="text-xs text-slate-400">
              ID: <span className="text-slate-200">{currentStudent.student_id}</span> • {currentStudent.major} ({currentStudent.year_level})
            </p>
          </div>
        </div>

        {/* Dropdown to switch perspective */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400">Select Student View:</span>
          <select
            className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            value={currentStudent.student_id}
            onChange={(e) => {
              const selected = students.find(s => s.student_id === e.target.value);
              if (selected) {
                setCurrentStudent(selected);
                setSelectedStudentId(selected.student_id);
              }
            }}
          >
            {students.map(s => (
              <option key={s.id} value={s.student_id}>{s.name} ({s.student_id})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Stats Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center space-y-1">
          <p className="text-xs text-slate-400">Current Registrar GPA</p>
          <p className="text-3xl font-extrabold text-white">{currentStudent.overall_gpa?.toFixed(2) ?? '3.10'}</p>
          <p className="text-[10px] text-slate-500">Official transcript grade</p>
        </div>

        <div className="bg-gradient-to-br from-indigo-900/50 to-violet-900/50 border border-indigo-500/40 p-5 rounded-2xl text-center space-y-1">
          <p className="text-xs text-indigo-300 font-semibold flex items-center justify-center space-x-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Predicted Final GPA</span>
          </p>
          <p className="text-4xl font-black text-indigo-200">{prediction.predicted_gpa.toFixed(2)}</p>
          <p className="text-[10px] text-indigo-400">Score Projection: {prediction.predicted_score}%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center space-y-1">
          <p className="text-xs text-slate-400">Academic Status</p>
          <p className={`text-xl font-bold mt-1 ${
            prediction.risk_level === 'High Risk' ? 'text-rose-400' : 'text-emerald-400'
          }`}>
            {prediction.risk_level}
          </p>
          <p className="text-[10px] text-slate-500">Based on midterm & attendance</p>
        </div>
      </div>

      {/* Course Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center space-x-2">
          <BookOpen className="w-4 h-4 text-indigo-400" />
          <span>My Course Grades & AI Projections</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs text-white">CS-301 Data Structures</span>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">3 Credits</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300 pt-1">
              <span>Midterm Score:</span>
              <span className="font-bold">{currentStudent.midterm_score}%</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300">
              <span>Predicted Final:</span>
              <span className="font-bold text-indigo-300">{prediction.predicted_score}%</span>
            </div>
          </div>

          <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs text-white">MATH-204 Calculus II</span>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">4 Credits</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300 pt-1">
              <span>Midterm Score:</span>
              <span className="font-bold">{Math.max(50, currentStudent.midterm_score - 5)}%</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300">
              <span>Predicted Final:</span>
              <span className="font-bold text-indigo-300">{Math.max(55, prediction.predicted_score - 3)}%</span>
            </div>
          </div>

          <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-xs text-white">PHYS-101 University Physics</span>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">4 Credits</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300 pt-1">
              <span>Midterm Score:</span>
              <span className="font-bold">{Math.min(100, currentStudent.midterm_score + 4)}%</span>
            </div>
            <div className="flex justify-between text-xs text-slate-300">
              <span>Predicted Final:</span>
              <span className="font-bold text-indigo-300">{Math.min(100, prediction.predicted_score + 2)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="bg-indigo-950/40 border border-indigo-900/50 p-5 rounded-3xl space-y-3">
        <h2 className="text-sm font-bold text-indigo-300 flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>AI Personal Action Strategy</span>
        </h2>
        <ul className="space-y-2 text-xs text-indigo-200">
          {prediction.recommendations.map((rec, i) => (
            <li key={i} className="flex items-start space-x-2 bg-slate-900/60 p-3 rounded-xl border border-indigo-900/30">
              <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <span>{rec}</span>
            </li>
          ))}
        </ul>
      </div>

    </div>
  );
}
