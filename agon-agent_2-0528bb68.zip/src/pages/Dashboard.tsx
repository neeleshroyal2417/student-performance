import React, { useState, useEffect } from 'react';
import {
  Users,
  AlertTriangle,
  GraduationCap,
  TrendingUp,
  Search,
  Filter,
  RefreshCw,
  Sparkles,
  ShieldAlert,
  ChevronRight,
  CheckCircle,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import StudentDetailModal from '../components/StudentDetailModal';
import AddStudentModal from '../components/AddStudentModal';
import AddInterventionModal from '../components/AddInterventionModal';

interface Student {
  id: number;
  student_id: string;
  name: string;
  email: string;
  major: string;
  year_level: string;
  overall_gpa: number;
  predicted_gpa: number;
  risk_level: string;
  attendance_rate: number;
  weekly_study_hours: number;
  assignment_completion_rate: number;
  midterm_score: number;
  lms_engagement_score: number;
}

export default function Dashboard() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('ALL');
  
  // Modals state
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [interventionStudentId, setInterventionStudentId] = useState<string | null>(null);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/students');
      if (res.ok) {
        const data = await res.json();
        setStudents(data);
      }
    } catch (err) {
      console.error('Failed to fetch students:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const totalStudents = students.length;
  const highRiskCount = students.filter(s => s.risk_level === 'High Risk').length;
  const moderateRiskCount = students.filter(s => s.risk_level === 'Moderate Risk').length;
  const topPerformersCount = students.filter(s => s.risk_level === 'Top Performer').length;
  const avgPredictedGPA = totalStudents > 0
    ? (students.reduce((acc, s) => acc + (s.predicted_gpa || 3.0), 0) / totalStudents).toFixed(2)
    : '3.12';

  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.student_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.major.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = riskFilter === 'ALL' || s.risk_level === riskFilter;
    return matchesSearch && matchesRisk;
  });

  const highRiskStudents = students.filter(s => s.risk_level === 'High Risk');

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto text-slate-100">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 md:space-y-0">
        <div>
          <span className="px-3 py-1 text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full inline-block mb-2">
            Academic Performance Intelligence
          </span>
          <h1 className="text-2xl font-bold text-white tracking-tight">Academic Advisor Command Center</h1>
          <p className="text-xs text-slate-400 max-w-2xl mt-1">
            Real-time machine learning predictions monitoring midterm drops, attendance flags, study habit shifts, and automated intervention recommendations.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={fetchStudents}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl border border-slate-700 transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-4 py-2.5 rounded-2xl text-xs font-semibold shadow-lg shadow-indigo-500/20 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>Enroll New Student</span>
          </button>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-xs font-medium text-slate-400">Total Active Roster</p>
            <p className="text-2xl font-bold text-white">{totalStudents}</p>
            <p className="text-[10px] text-slate-500">Enrolled across 6 majors</p>
          </div>
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-xs font-medium text-slate-400">Class Avg Predicted GPA</p>
            <p className="text-2xl font-bold text-indigo-300">{avgPredictedGPA}</p>
            <p className="text-[10px] text-emerald-400 flex items-center space-x-0.5">
              <ArrowUpRight className="w-3 h-3" />
              <span>+0.14 vs last term</span>
            </p>
          </div>
          <div className="p-3 bg-violet-500/10 text-violet-400 rounded-2xl border border-violet-500/20">
            <GraduationCap className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-rose-900/40 p-5 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-xs font-medium text-slate-400">At High Academic Risk</p>
            <p className="text-2xl font-bold text-rose-400">{highRiskCount}</p>
            <p className="text-[10px] text-rose-400 font-medium">Action Required Immediately</p>
          </div>
          <div className="p-3 bg-rose-500/10 text-rose-400 rounded-2xl border border-rose-500/20">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-xs font-medium text-slate-400">Top Performers (&gt;3.6)</p>
            <p className="text-2xl font-bold text-emerald-400">{topPerformersCount}</p>
            <p className="text-[10px] text-slate-500">Low intervention needs</p>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-2xl border border-emerald-500/20">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* High-Risk Priority Alerts Ticker / Cards */}
      {highRiskStudents.length > 0 && (
        <div className="bg-rose-950/20 border border-rose-900/50 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-rose-400">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
              <h2 className="text-sm font-bold uppercase tracking-wider">Priority Academic Interventions Required</h2>
            </div>
            <span className="text-xs font-medium text-rose-300">
              {highRiskStudents.length} Students Flagged
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {highRiskStudents.slice(0, 3).map((stu) => (
              <div
                key={stu.id}
                onClick={() => setSelectedStudent(stu)}
                className="bg-slate-900/90 border border-rose-800/60 hover:border-rose-500/80 p-3.5 rounded-xl cursor-pointer transition-all space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-xs text-white group-hover:text-rose-300 transition-colors">
                    {stu.name}
                  </span>
                  <span className="text-[10px] text-slate-400">{stu.student_id}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Predicted GPA:</span>
                  <span className="font-bold text-rose-400">{stu.predicted_gpa.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Attendance: {stu.attendance_rate}%</span>
                  <span>Midterm: {stu.midterm_score}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Student Roster Table Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
        
        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search student by name, ID, or major..."
              className="w-full bg-slate-800 border border-slate-700/80 rounded-2xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <div className="flex bg-slate-800 p-1 rounded-2xl border border-slate-700">
              {['ALL', 'High Risk', 'Moderate Risk', 'Low Risk', 'Top Performer'].map((tier) => (
                <button
                  key={tier}
                  onClick={() => setRiskFilter(tier)}
                  className={`px-3 py-1 text-[11px] font-medium rounded-xl transition-all ${
                    riskFilter === tier
                      ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Major & Level</th>
                <th className="py-3 px-4">Midterm</th>
                <th className="py-3 px-4">Attendance</th>
                <th className="py-3 px-4">Study Hrs</th>
                <th className="py-3 px-4">Predicted GPA</th>
                <th className="py-3 px-4">Risk Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    <div className="flex flex-col items-center space-y-2">
                      <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                      <span>Running Predictive Engine queries...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No student records matching filters.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((stu) => (
                  <tr
                    key={stu.id}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                    onClick={() => setSelectedStudent(stu)}
                  >
                    <td className="py-3 px-4 font-medium text-white flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-indigo-300">
                        {stu.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="font-semibold group-hover:text-indigo-300 transition-colors">{stu.name}</p>
                        <p className="text-[10px] text-slate-400">{stu.student_id}</p>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-slate-300">
                      <p className="font-medium">{stu.major}</p>
                      <p className="text-[10px] text-slate-500">{stu.year_level}</p>
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-200">
                      {stu.midterm_score}%
                    </td>

                    <td className="py-3 px-4">
                      <span className={stu.attendance_rate < 80 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                        {stu.attendance_rate}%
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-300">
                      {stu.weekly_study_hours} h/wk
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-extrabold text-sm text-indigo-200">
                        {stu.predicted_gpa?.toFixed(2) ?? '3.10'}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      {stu.risk_level === 'High Risk' && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full inline-flex items-center space-x-1">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          <span>High Risk</span>
                        </span>
                      )}
                      {stu.risk_level === 'Moderate Risk' && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full inline-flex items-center space-x-1">
                          <Clock className="w-2.5 h-2.5" />
                          <span>Moderate</span>
                        </span>
                      )}
                      {stu.risk_level === 'Low Risk' && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full inline-flex items-center space-x-1">
                          <CheckCircle className="w-2.5 h-2.5" />
                          <span>Low Risk</span>
                        </span>
                      )}
                      {stu.risk_level === 'Top Performer' && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full inline-flex items-center space-x-1">
                          <Sparkles className="w-2.5 h-2.5" />
                          <span>Top Tier</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedStudent(stu);
                        }}
                        className="text-xs text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-700"
                      >
                        <span>Inspect</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedStudent && (
        <StudentDetailModal
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          onOpenIntervention={(id) => setInterventionStudentId(id)}
          onUpdateStudent={(updated) => {
            setStudents(prev => prev.map(s => s.id === updated.id ? updated : s));
            setSelectedStudent(updated);
          }}
        />
      )}

      {/* Add Student Modal */}
      {showAddModal && (
        <AddStudentModal
          onClose={() => setShowAddModal(false)}
          onAdded={fetchStudents}
        />
      )}

      {/* Add Intervention Modal */}
      {interventionStudentId && (
        <AddInterventionModal
          defaultStudentId={interventionStudentId}
          onClose={() => setInterventionStudentId(null)}
          onAdded={fetchStudents}
        />
      )}

    </div>
  );
}
