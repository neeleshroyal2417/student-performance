import React, { useState, useEffect } from 'react';
import { ShieldAlert, Plus, CheckCircle, Clock, Search, Filter } from 'lucide-react';
import AddInterventionModal from '../components/AddInterventionModal';

interface Intervention {
  id: number;
  student_id: string;
  advisor_name: string;
  title: string;
  type: string;
  status: string;
  notes: string;
  date_logged: string;
}

export default function InterventionsPage() {
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [search, setSearch] = useState('');

  const fetchInterventions = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/interventions');
      if (res.ok) {
        const data = await res.json();
        setInterventions(data);
      }
    } catch (err) {
      console.error('Failed to load interventions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInterventions();
  }, []);

  const handleUpdateStatus = async (id: number, newStatus: string) => {
    try {
      const res = await fetch('/api/interventions', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus })
      });
      if (res.ok) {
        fetchInterventions();
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const filtered = interventions.filter(i =>
    i.student_id.toLowerCase().includes(search.toLowerCase()) ||
    i.title.toLowerCase().includes(search.toLowerCase()) ||
    i.advisor_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto text-slate-100">
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Academic Intervention & Support Tracker</h1>
          <p className="text-xs text-slate-400 mt-1">
            Log and track 1-on-1 tutoring, counseling, wellness checks, and parent outreach for at-risk students.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-rose-600 hover:bg-rose-500 text-white px-4 py-2.5 rounded-2xl text-xs font-semibold shadow-lg shadow-rose-900/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Academic Action</span>
        </button>
      </div>

      {/* Filter */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search intervention by student ID or title..."
            className="w-full bg-slate-800 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Interventions Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-500 text-xs">
            Loading intervention records...
          </div>
        ) : filtered.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 text-xs">
            No active intervention records found.
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 relative flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
                    {item.type}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {item.date_logged ? new Date(item.date_logged).toLocaleDateString() : 'Recent'}
                  </span>
                </div>

                <h3 className="font-bold text-sm text-white">{item.title}</h3>
                <p className="text-xs text-slate-400">
                  Student ID: <span className="text-slate-200 font-semibold">{item.student_id}</span>
                </p>
                <p className="text-xs text-slate-400">
                  Advisor: <span className="text-slate-200">{item.advisor_name}</span>
                </p>

                {item.notes && (
                  <p className="text-xs bg-slate-800/50 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    "{item.notes}"
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className={`text-[11px] font-semibold flex items-center space-x-1 ${
                  item.status === 'Completed' ? 'text-emerald-400' : 'text-amber-400'
                }`}>
                  {item.status === 'Completed' ? (
                    <CheckCircle className="w-3.5 h-3.5" />
                  ) : (
                    <Clock className="w-3.5 h-3.5" />
                  )}
                  <span>{item.status}</span>
                </span>

                {item.status !== 'Completed' && (
                  <button
                    onClick={() => handleUpdateStatus(item.id, 'Completed')}
                    className="text-[11px] font-medium text-emerald-400 hover:text-emerald-300 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-700"
                  >
                    Mark Completed
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {showAddModal && (
        <AddInterventionModal
          onClose={() => setShowAddModal(false)}
          onAdded={fetchInterventions}
        />
      )}

    </div>
  );
}
