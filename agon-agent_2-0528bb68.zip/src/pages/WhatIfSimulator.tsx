import React, { useState } from 'react';
import { Sliders, Sparkles, AlertTriangle, TrendingUp, CheckCircle2, RotateCcw } from 'lucide-react';
import { calculateStudentPrediction } from '../lib/predictionEngine';

export default function WhatIfSimulator() {
  const [midtermScore, setMidtermScore] = useState(72);
  const [attendanceRate, setAttendanceRate] = useState(82);
  const [studyHours, setStudyHours] = useState(10);
  const [assignmentRate, setAssignmentRate] = useState(80);
  const [lmsScore, setLmsScore] = useState(70);

  const prediction = calculateStudentPrediction({
    midterm_score: midtermScore,
    attendance_rate: attendanceRate,
    weekly_study_hours: studyHours,
    assignment_completion_rate: assignmentRate,
    lms_engagement_score: lmsScore
  });

  const resetDefaults = () => {
    setMidtermScore(72);
    setAttendanceRate(82);
    setStudyHours(10);
    setAssignmentRate(80);
    setLmsScore(70);
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-6xl mx-auto text-slate-100">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 rounded-3xl gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-indigo-400" />
            <h1 className="text-2xl font-bold text-white tracking-tight">Interactive 'What-If' Grade Simulator</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Simulate how changes in study hours, lecture attendance, assignment effort, and test results dynamically impact your predicted final score and overall GPA.
          </p>
        </div>

        <button
          onClick={resetDefaults}
          className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3.5 py-2 rounded-2xl text-xs font-semibold border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sliders</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Sliders Column */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <h2 className="text-sm font-bold text-white border-b border-slate-800 pb-3">
            Adjust Academic Input Parameters
          </h2>

          <div className="space-y-5 text-xs">
            {/* Midterm Score */}
            <div className="space-y-2">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Midterm Exam Score</span>
                <span className="text-indigo-400 font-bold">{midtermScore}%</span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                value={midtermScore}
                onChange={e => setMidtermScore(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>30% (Failing)</span>
                <span>70% (Average)</span>
                <span>100% (Perfect)</span>
              </div>
            </div>

            {/* Attendance Rate */}
            <div className="space-y-2">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Class Attendance Rate</span>
                <span className="text-indigo-400 font-bold">{attendanceRate}%</span>
              </div>
              <input
                type="range"
                min="40"
                max="100"
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                value={attendanceRate}
                onChange={e => setAttendanceRate(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>40% (Critical)</span>
                <span>80% (Warning)</span>
                <span>100% (Full)</span>
              </div>
            </div>

            {/* Weekly Study Hours */}
            <div className="space-y-2">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Weekly Self-Study Time</span>
                <span className="text-indigo-400 font-bold">{studyHours} Hours / Week</span>
              </div>
              <input
                type="range"
                min="0"
                max="35"
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                value={studyHours}
                onChange={e => setStudyHours(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0 hrs</span>
                <span>15 hrs (Target)</span>
                <span>35 hrs</span>
              </div>
            </div>

            {/* Assignment Completion */}
            <div className="space-y-2">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">Assignment Submission Rate</span>
                <span className="text-indigo-400 font-bold">{assignmentRate}%</span>
              </div>
              <input
                type="range"
                min="40"
                max="100"
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                value={assignmentRate}
                onChange={e => setAssignmentRate(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>40%</span>
                <span>80%</span>
                <span>100%</span>
              </div>
            </div>

            {/* LMS Engagement */}
            <div className="space-y-2">
              <div className="flex justify-between font-medium">
                <span className="text-slate-300">LMS Online Portal Activity</span>
                <span className="text-indigo-400 font-bold">{lmsScore} Pts</span>
              </div>
              <input
                type="range"
                min="20"
                max="100"
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                value={lmsScore}
                onChange={e => setLmsScore(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>20 pts</span>
                <span>60 pts</span>
                <span>100 pts</span>
              </div>
            </div>
          </div>
        </div>

        {/* Prediction Results Card Column */}
        <div className="lg:col-span-5 space-y-4">
          
          <div className="bg-gradient-to-br from-indigo-900/60 via-slate-900 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>Simulated AI Result</span>
              </span>

              <span className={`px-3 py-1 text-xs font-semibold rounded-full border ${
                prediction.risk_level === 'High Risk'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                  : prediction.risk_level === 'Moderate Risk'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : prediction.risk_level === 'Top Performer'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-blue-500/20 text-blue-300 border-blue-500/30'
              }`}>
                {prediction.risk_level}
              </span>
            </div>

            <div className="text-center py-2 space-y-1">
              <p className="text-xs text-slate-400 font-medium">Predicted Final GPA</p>
              <p className="text-5xl font-black text-white tracking-tight">{prediction.predicted_gpa.toFixed(2)}</p>
              <p className="text-xs text-indigo-300 font-semibold">
                Overall Score Projection: {prediction.predicted_score}%
              </p>
            </div>

            {/* Score Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0.0 (Fail)</span>
                <span>2.0 (Passing)</span>
                <span>4.0 (Honor)</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full transition-all duration-300"
                  style={{ width: `${(prediction.predicted_gpa / 4.0) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Key Drivers */}
            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
              <p className="text-xs font-semibold text-slate-300">Identified Risk Factors:</p>
              <ul className="space-y-1 text-xs text-slate-400">
                {prediction.key_factors.map((factor, i) => (
                  <li key={i} className="flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                    <span>{factor}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* AI Action Plan */}
            <div className="bg-indigo-950/50 p-4 rounded-2xl border border-indigo-800/40 space-y-2">
              <p className="text-xs font-semibold text-indigo-300">Customized Action Plan:</p>
              <ul className="space-y-1.5 text-xs text-indigo-200">
                {prediction.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
