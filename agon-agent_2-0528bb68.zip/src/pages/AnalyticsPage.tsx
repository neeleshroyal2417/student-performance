import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, PieChart, Users, Zap, Award } from 'lucide-react';

export default function AnalyticsPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await fetch('/api/analytics');
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch (err) {
        console.error('Failed to load analytics:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto text-slate-100">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Predictive Model Insights & Analytics</h1>
        <p className="text-xs text-slate-400 mt-1">
          Machine learning feature weights, factor correlation distributions, and cohort performance statistics.
        </p>
      </div>

      {/* Feature Weights / Model Parameters Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Midterm Score Weight</span>
            <span className="font-bold text-indigo-400">35%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full" style={{ width: '35%' }}></div>
          </div>
          <p className="text-[10px] text-slate-500">Highest correlation with final exam outcome</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Assignment Completion</span>
            <span className="font-bold text-indigo-400">25%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full" style={{ width: '25%' }}></div>
          </div>
          <p className="text-[10px] text-slate-500">Indicator of student discipline & consistency</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Attendance Rate Weight</span>
            <span className="font-bold text-indigo-400">20%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full" style={{ width: '20%' }}></div>
          </div>
          <p className="text-[10px] text-slate-500">Strong indicator of academic drop risk</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Study Hours & LMS Activity</span>
            <span className="font-bold text-indigo-400">20%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full" style={{ width: '20%' }}></div>
          </div>
          <p className="text-[10px] text-slate-500">Effort & digital interaction metric</p>
        </div>
      </div>

      {/* Visual Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Risk Level Distribution Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center space-x-2">
              <PieChart className="w-4 h-4 text-indigo-400" />
              <span>Risk Tier Breakdown</span>
            </h2>
            <span className="text-xs text-slate-400">Cohort Distribution</span>
          </div>

          <div className="space-y-4 text-xs pt-2">
            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>High Risk Tier</span>
                <span className="font-bold text-rose-400">18.5%</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '18.5%' }}></div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Moderate Risk Tier</span>
                <span className="font-bold text-amber-400">31.2%</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '31.2%' }}></div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Low Risk Tier</span>
                <span className="font-bold text-blue-400">32.8%</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full" style={{ width: '32.8%' }}></div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Top Performers (&gt;3.6 GPA)</span>
                <span className="font-bold text-emerald-400">17.5%</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '17.5%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Attendance vs GPA Correlation Matrix */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center space-x-2">
              <BarChart3 className="w-4 h-4 text-indigo-400" />
              <span>Study Hours vs Predicted GPA Correlation</span>
            </h2>
            <span className="text-xs text-slate-400">Statistical Analysis</span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center text-xs pt-2">
            <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
              <p className="text-[10px] text-slate-400">&lt; 5 hrs/wk</p>
              <p className="text-lg font-bold text-rose-400">2.14 GPA</p>
              <p className="text-[9px] text-slate-500">At Risk</p>
            </div>

            <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
              <p className="text-[10px] text-slate-400">5 - 12 hrs/wk</p>
              <p className="text-lg font-bold text-amber-400">2.85 GPA</p>
              <p className="text-[9px] text-slate-500">Moderate</p>
            </div>

            <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
              <p className="text-[10px] text-slate-400">12 - 20 hrs/wk</p>
              <p className="text-lg font-bold text-blue-400">3.42 GPA</p>
              <p className="text-[9px] text-slate-500">Optimal</p>
            </div>

            <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
              <p className="text-[10px] text-slate-400">&gt; 20 hrs/wk</p>
              <p className="text-lg font-bold text-emerald-400">3.88 GPA</p>
              <p className="text-[9px] text-slate-500">Top Tier</p>
            </div>
          </div>

          <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 text-xs text-slate-300">
            <p className="font-semibold text-indigo-300 mb-1">Key Insight:</p>
            <p className="text-[11px] text-slate-400">
              Students who maintain at least 14 hours of weekly study and over 85% attendance show a 91% likelihood of achieving a GPA over 3.2.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
