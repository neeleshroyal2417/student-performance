import React, { useState, useEffect } from 'react';
import { Search, Filter, Plus, ChevronRight, AlertTriangle, Sparkles, RefreshCw } from 'lucide-react';
import StudentDetailModal from '../components/StudentDetailModal';
import AddStudentModal from '../components/AddStudentModal';
import AddInterventionModal from '../components/AddInterventionModal';

interface Student {
  id: number;
  student_id: string;
  name: string;
  email: string;
  major: string;
  year_level: string;
  overall_gpa: number;
  predicted_gpa: number;
  risk_level: string;
  attendance_rate: number;
  weekly_study_hours: number;
  assignment_completion_rate: number;
  midterm_score: number;
  lms_engagement_score: number;
}

export default function StudentsList() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [majorFilter, setMajorFilter] = useState('ALL');
  const [riskFilter, setRiskFilter] = useState('ALL');

  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [interventionStudentId, setInterventionStudentId] = useState<string | null>(null);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/students');
      if (res.ok) {
        const data = await res.json();
        setStudents(data);
      }
    } catch (err) {
      console.error('Error fetching students:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const majors = Array.from(new Set(students.map(s => s.major))).filter(Boolean);

  const filtered = students.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
                        s.student_id.toLowerCase().includes(search.toLowerCase()) ||
                        s.email.toLowerCase().includes(search.toLowerCase());
    const matchMajor = majorFilter === 'ALL' || s.major === majorFilter;
    const matchRisk = riskFilter === 'ALL' || s.risk_level === riskFilter;
    return matchSearch && matchMajor && matchRisk;
  });

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto text-slate-100">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Student Academic Directory</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Full cohort records, predictive model parameters, and individual performance profiles.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-4 py-2 rounded-2xl text-xs font-semibold shadow-lg shadow-indigo-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Student Record</span>
        </button>
      </div>

      {/* Filters bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by student name, ID or email..."
            className="w-full bg-slate-800 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto">
          <select
            className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            value={majorFilter}
            onChange={e => setMajorFilter(e.target.value)}
          >
            <option value="ALL">All Majors</option>
            {majors.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          <select
            className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            value={riskFilter}
            onChange={e => setRiskFilter(e.target.value)}
          >
            <option value="ALL">All Risk Tiers</option>
            <option value="High Risk">High Risk</option>
            <option value="Moderate Risk">Moderate Risk</option>
            <option value="Low Risk">Low Risk</option>
            <option value="Top Performer">Top Performer</option>
          </select>

          <button
            onClick={fetchStudents}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl border border-slate-700"
            title="Refresh list"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Grid of Student Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-500 text-xs">
            Loading student roster...
          </div>
        ) : filtered.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 text-xs">
            No student records found matching search filters.
          </div>
        ) : (
          filtered.map((stu) => (
            <div
              key={stu.id}
              onClick={() => setSelectedStudent(stu)}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-5 rounded-2xl cursor-pointer transition-all space-y-4 hover:shadow-xl group"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center font-bold text-white text-sm shadow-md">
                    {stu.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white group-hover:text-indigo-300 transition-colors">
                      {stu.name}
                    </h3>
                    <p className="text-[10px] text-slate-400">{stu.student_id} • {stu.major}</p>
                  </div>
                </div>

                <span className={`px-2.5 py-1 text-[10px] font-semibold rounded-full border ${
                  stu.risk_level === 'High Risk'
                    ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                    : stu.risk_level === 'Moderate Risk'
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                    : stu.risk_level === 'Top Performer'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                }`}>
                  {stu.risk_level}
                </span>
              </div>

              {/* Metrics row */}
              <div className="grid grid-cols-3 gap-2 bg-slate-800/40 p-3 rounded-xl border border-slate-800/80 text-center">
                <div>
                  <p className="text-[10px] text-slate-400">Predicted GPA</p>
                  <p className="text-sm font-extrabold text-indigo-300">{stu.predicted_gpa.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400">Attendance</p>
                  <p className="text-sm font-bold text-slate-200">{stu.attendance_rate}%</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400">Study Time</p>
                  <p className="text-sm font-bold text-slate-200">{stu.weekly_study_hours}h/wk</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] pt-1">
                <span className="text-slate-400">Midterm: {stu.midterm_score}%</span>
                <span className="text-indigo-400 group-hover:underline font-medium flex items-center space-x-1">
                  <span>View Details</span>
                  <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {selectedStudent && (
        <StudentDetailModal
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          onOpenIntervention={(id) => setInterventionStudentId(id)}
          onUpdateStudent={(updated) => {
            setStudents(prev => prev.map(s => s.id === updated.id ? updated : s));
            setSelectedStudent(updated);
          }}
        />
      )}

      {showAddModal && (
        <AddStudentModal
          onClose={() => setShowAddModal(false)}
          onAdded={fetchStudents}
        />
      )}

      {interventionStudentId && (
        <AddInterventionModal
          defaultStudentId={interventionStudentId}
          onClose={() => setInterventionStudentId(null)}
          onAdded={fetchStudents}
        />
      )}

    </div>
  );
}
