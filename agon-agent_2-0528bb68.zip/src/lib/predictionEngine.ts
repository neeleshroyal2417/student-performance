export interface StudentInputData {
  midterm_score: number;
  attendance_rate: number;
  weekly_study_hours: number;
  assignment_completion_rate: number;
  lms_engagement_score: number;
  sleep_hours_avg?: number;
}

export interface PredictionResult {
  predicted_score: number;
  predicted_gpa: number;
  risk_level: 'High Risk' | 'Moderate Risk' | 'Low Risk' | 'Top Performer';
  risk_score: number;
  key_factors: string[];
  recommendations: string[];
}

export function calculateStudentPrediction(input: StudentInputData): PredictionResult {
  const midterm = Math.max(0, Math.min(100, Number(input.midterm_score) || 0));
  const attendance = Math.max(0, Math.min(100, Number(input.attendance_rate) || 0));
  const studyHours = Math.max(0, Math.min(40, Number(input.weekly_study_hours) || 0));
  const assignment = Math.max(0, Math.min(100, Number(input.assignment_completion_rate) || 0));
  const lms = Math.max(0, Math.min(100, Number(input.lms_engagement_score) || 0));

  const studyNormalized = Math.min(100, (studyHours / 25) * 100);

  // Weighted Score Formula
  const score = (midterm * 0.35) + (assignment * 0.25) + (attendance * 0.20) + (studyNormalized * 0.10) + (lms * 0.10);
  const predicted_score = Math.round(score * 10) / 10;

  let gpa = 0.0;
  if (predicted_score >= 93) gpa = 4.0;
  else if (predicted_score >= 90) gpa = 3.7;
  else if (predicted_score >= 87) gpa = 3.3;
  else if (predicted_score >= 83) gpa = 3.0;
  else if (predicted_score >= 80) gpa = 2.7;
  else if (predicted_score >= 77) gpa = 2.3;
  else if (predicted_score >= 73) gpa = 2.0;
  else if (predicted_score >= 70) gpa = 1.7;
  else if (predicted_score >= 65) gpa = 1.3;
  else if (predicted_score >= 60) gpa = 1.0;
  else gpa = 0.0;

  const predicted_gpa = Math.round(gpa * 100) / 100;

  const factors: string[] = [];
  if (attendance < 75) factors.push(`Critical Attendance Drop (${attendance}%)`);
  else if (attendance < 85) factors.push(`Sub-optimal Attendance (${attendance}%)`);

  if (studyHours < 8) factors.push(`Low Weekly Study Time (${studyHours} hrs/wk)`);
  if (midterm < 65) factors.push(`Low Midterm Grade (${midterm}%)`);
  if (assignment < 75) factors.push(`Missing Assignments (${assignment}% rate)`);
  if (lms < 50) factors.push(`Low Portal Activity (${lms} pts)`);

  let risk_level: 'High Risk' | 'Moderate Risk' | 'Low Risk' | 'Top Performer' = 'Low Risk';

  if (predicted_gpa < 2.3 || attendance < 72 || midterm < 60) {
    risk_level = 'High Risk';
  } else if (predicted_gpa < 2.9 || attendance < 82 || assignment < 80) {
    risk_level = 'Moderate Risk';
  } else if (predicted_gpa >= 3.6 && attendance >= 90 && assignment >= 90) {
    risk_level = 'Top Performer';
  } else {
    risk_level = 'Low Risk';
  }

  const risk_score = Math.round(100 - predicted_score);

  const recs: string[] = [];
  if (attendance < 80) recs.push('Schedule attendance counseling & set morning class alarm alerts.');
  if (studyHours < 12) recs.push(`Increase weekly study duration by ${Math.ceil(14 - studyHours)} hours.`);
  if (midterm < 70) recs.push('Enroll in subject peer-tutoring & review key exam problem sets.');
  if (assignment < 85) recs.push('Use assignment planner & visit instructor office hours for homework guidance.');
  if (lms < 60) recs.push('Regularly participate in LMS forums and access extra practice modules.');
  if (recs.length === 0) recs.push('Maintain current high academic momentum and assist peer study circles.');

  return {
    predicted_score,
    predicted_gpa,
    risk_level,
    risk_score,
    key_factors: factors.length > 0 ? factors : ['Consistent performance', 'Good attendance'],
    recommendations: recs
  };
}
